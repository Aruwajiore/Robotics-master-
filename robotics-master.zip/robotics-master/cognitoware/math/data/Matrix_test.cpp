/*
 * Matrix_test.cpp
 *
 *  Copyright (c) 2015, Norman Alan Oursland
 *  All rights reserved.
 */

#include <cognitoware/math/data/Matrix.h>

namespace cognitoware {
namespace math {
namespace data {

}  // namespace data
}  // namespace math
}  // namespace cognitoware
