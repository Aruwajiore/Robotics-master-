/*
 * GaussianMoment_test.cpp
 *
 *  Copyright (c) 2015, Norman Alan Oursland
 *  All rights reserved.
 */

#include <cognitoware/math/probability/continuous/GaussianMoment.h>

namespace cognitoware {
namespace math {
namespace probability {
namespace continuous {

}  // namespace continuous
}  // namespace probability
}  // namespace math
}  // namespace cognitoware
